import cart from "./modules/cart";
import second from "./modules/second";

cart()
second()