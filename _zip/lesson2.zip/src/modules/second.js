const second = () => {
    const cartBtn = document.getElementById('cart')

    console.log('second');
}

export default second